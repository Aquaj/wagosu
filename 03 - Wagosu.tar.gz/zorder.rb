module ZOrder
  BACKGROUND, STARS, PLAYER, UI = *0..3
end
